import time
from selenium import webdriver
driver= webdriver.Chrome()
driver.get("https://lms.umt.edu.pk/login/index.php")
driver.find_element_by_id("username").send_keys("F2019065240")
driver.find_element_by_id("password").send_keys("fHY8Su@7")
time.sleep(1)
driver.find_element_by_id("loginbtn").click()
time.sleep(1)
Mycourse=driver.find_elements_by_class_name("media-body")
for i in range(5,len(Mycourse)):
        print(Mycourse[i].text)
        driver.close()



