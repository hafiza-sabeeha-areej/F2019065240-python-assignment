

# Create your views here.
def index(request):
    return render(request, 'Boot.html')


def mydata(request):
    if request.method == 'POST':
        u = str(request.POST['un'])
        E = str(request.POST['em'])
        P1 = str(request.POST['exampleInputPassword1'])
        P2 = str(request.POST['exampleInputPassword1'])
        if P1 == P2:
            userobj = User()
            userobj.username = u;
            userobj.email = E;
            userobj.password = P1;
            userobj.save();
            return HttpResponse("Thank You for signup")
        else:
            return HttpResponse("Your entered password is wrong")
            print(u, E, P1, P2)

    else:
        return render(request, 'Boot.html')


def main(request, id):
    return HttpResponse(id)


from django.shortcuts import render,HttpResponse

# Create your views here.


# Create your views here.
