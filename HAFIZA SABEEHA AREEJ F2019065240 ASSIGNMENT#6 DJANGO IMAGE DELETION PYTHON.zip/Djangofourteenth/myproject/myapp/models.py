from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
# Create your models here.
class signup(models.Model):
    myprofile = models.ImageField(blank=True, null=True, upload_to="Images/", default="/static/scaling.png")
    name = models.CharField(max_length=100)
def __str__str(self):
    return str(self.name)
@receiver(post_delete,sender=signup)
def ac_del(sender,instance,**kwargs):
    instance.myprofile.delete(save=False)
    print("Data is deleted successfully")
